import pyscannerbit.ScannerBit.python.ScannerBit as scan
s = scan.scan(True)

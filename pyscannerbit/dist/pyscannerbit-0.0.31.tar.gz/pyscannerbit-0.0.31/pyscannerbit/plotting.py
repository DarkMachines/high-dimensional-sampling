"""Helper routines for making some simple plots"""

